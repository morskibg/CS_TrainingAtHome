﻿

namespace BookShop.Data
{
    public class ServerConfig
    {
        public const string ConnectionString = "Server=DESKTOP-QFU7S9K;Database=BookShop;Trusted_Connection=True;";
    }
}

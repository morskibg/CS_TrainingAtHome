﻿namespace BookShop.Models
{
    public enum EditionType
    {
        Normal,
        Photo,
        Gold
    }
}